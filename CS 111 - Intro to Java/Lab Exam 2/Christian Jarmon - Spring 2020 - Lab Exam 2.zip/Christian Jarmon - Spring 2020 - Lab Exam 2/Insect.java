abstract class Insect {
static int height;

public static void Insect(int hei) {
height = hei;


}//con ends

public  int getHeight() {
return height;


}//getHeight ends


public static void setHeight(int hei2) {
height = hei2;


}//setHeight

public abstract int wingspan();


 public static void println(String statement) {
 System.out.println(statement);
 
 }
 public static void println(){
 System.out.println();
 }

}//insect ends