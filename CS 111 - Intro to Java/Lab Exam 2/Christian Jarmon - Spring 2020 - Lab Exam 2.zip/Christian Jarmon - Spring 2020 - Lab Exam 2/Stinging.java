interface Stinging {

public abstract int sting(); //sting method ends



}//stinging ends