class Wasp extends Insect implements Stinging{
static int venom;

public Wasp(int hei4, int ven2) {
super.Insect(hei4);
venom = ven2;


}//con ends
public static int getVenom() {
return venom;
 
 
}//getVenom ends
public  void setVenom(int ven) {
venom = ven;


}//set ends

public int wingspan() {
return height/venom;


}//wingspan ends
public  int sting() {
return height * venom;



}//Sting ends
public String toString() {
return "This is a wasp that is " + height + " cm tall, and carries " + venom + "kg of venom." ;
}//toString ends




}//wasp ends