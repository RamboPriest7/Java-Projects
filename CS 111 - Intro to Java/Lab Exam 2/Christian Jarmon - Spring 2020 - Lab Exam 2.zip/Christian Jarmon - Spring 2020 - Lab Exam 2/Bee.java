class Bee extends Insect implements Stinging {
static int pollen;

public Bee(int hei3, int pol2) {
super.Insect(hei3);
pollen = pol2;


}//con ends
public static int getPollen() {
return pollen;
 
 
}//getPollen ends
public static void setPollen(int pol) {
pollen = pol;


}//set ends

public int wingspan() {
return height - pollen;


}//wingspan ends
public int sting() {

return height + pollen;


}//Sting ends
public String toString() {

return "This is a bee that is " + height + " cm tall, and carries " + pollen + "kg of pollen.";




}//toString ends





}//bee ends