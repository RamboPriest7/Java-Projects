/* Christian Jarmon

CMPSCI 111L � Spring 2020

Lab Exam 2 */

import java.util.Random;
import java.util.Scanner;

 class CMPSCI111Lab2 { 
 static Insect [] insects;
public static void main(String [] args) {


 
final int EXIT_OPTION = 4;
int option = 0;
while (option != EXIT_OPTION) {
   //input
   Scanner input = new Scanner(System.in);
   createInsects();
   println("Select an option:");
   println("1) Print out every insect.");
   println("2) Find a random insect from the array");
   println("3) Change every insect's variables");
   println(EXIT_OPTION + ") Exit");
   System.out.print("Enter a number: ");
   if (input.hasNextInt()) {
    option = input.nextInt();
   } else {
    option = 0;
   }
   input.nextLine();
   //calc and out
   switch (option) {
    case 1:
    printInsects();
         break;
    case 2:
     findInsects(0, (insects.length)-1);
     break;
    case 3:
     changeInsects();
     break;
    case EXIT_OPTION:
     println("Goodbye");
     break;
    default:
     println("Bad input, try again.");
   }//switch ends
   println();
  }//while ends






}//main ends


//create insects
 public static void createInsects() {
  Random gen1 = new Random();
 insects = new Insect[4];
  
  for (int i = 0; i < insects.length; i++) {
  int num1, num2;
  num1 = (gen1.nextInt(20) + 11);
  num2 = (gen1.nextInt(6) + 2);
  insects[i] = ((gen1.nextBoolean()) ? new Bee(num1, num2) : new Wasp(num1, num2));
  
  }//for ends
  

  println(insects.length + " insects have been created.");
  
 
 }//Create insects ends
 
//printInsects
 public static void printInsects() {
  for (int i = 0; i < insects.length; i++) {
  println("Current insect is " + insects[i]);
  insects[i].toString();
  println("It has a wingspan of " + insects[i].wingspan() + " cm.");
  if (insects[i] instanceof Stinging)  {
  Stinging stinger = (Stinging) insects[i];
  println("And a sting that lasts for " +  stinger.sting() +  " seconds.");
  }
 
  }//for loop ends
  
  
  
  
  
 }//printInsects ends
 
//findInsects
 public static void findInsects(int bottom, int top) {
 println("Recursive method started: Finding an insect...(" + bottom + "-" + top + ")");
 if (bottom < top) {
 int bottomHeight, topHeight, combinedHeight;
 bottomHeight = insects[bottom].getHeight();
  topHeight = insects[top].getHeight();
  combinedHeight = bottomHeight + topHeight;
 if (combinedHeight % 2 == 0) 
  findInsects(bottom, top-1);
  else findInsects(bottom + 1, top);
 
 }//if ends
 
 
 
 
 
 if (top == bottom) 
 println("Found an insect at index " + top + " " + insects[top + 1]);
 
 
 }//findInsects ends
//change Insects
public static void changeInsects() {

for (int i = 0; i < insects.length; i++) {
int newHeight = insects[i].getHeight() * 3;
insects[i].setHeight(newHeight);

if (insects[i] instanceof Bee) {
 Bee bee = (Bee) insects[i];
int newPollen = bee.getPollen() * 2;
bee.setPollen(newPollen);
}else if (insects[i] instanceof Wasp) {

Wasp wasp = (Wasp) insects[i];
int newVenom = wasp.getVenom() * 2;
wasp.setVenom(newVenom);



}// if ends



}//for ends

println(insects.length  + " insects have been changed.");


}//changeInsects ends
 public static void println(String statement) {
 System.out.println(statement);
 
 }
 public static void println(){
 System.out.println();
 }


}//class ends