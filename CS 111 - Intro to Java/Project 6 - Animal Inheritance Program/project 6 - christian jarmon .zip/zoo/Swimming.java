/* Christian JArmon
CMPSCI 111L - Spring 2020
Project 6 */
public interface Swimming {
 public void swim();
}