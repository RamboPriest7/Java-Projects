/* Christian Jarmon
CMPSCI 111L - Spring 2020
Project 6 */
public interface Flying {
 public void fly();
}