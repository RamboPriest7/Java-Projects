/* Christian Jarmon
CMPSCI 111L - Spring 2020
Project 6 */
public abstract class Animal {
 protected int number;
 public Animal(int number) {
  this.number = number;
 }
 public abstract void showProfile();
}